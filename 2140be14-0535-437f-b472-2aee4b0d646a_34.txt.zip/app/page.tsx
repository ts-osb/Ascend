'use client';

import Hero from '../components/Hero';
import ProblemSection from '../components/ProblemSection';
import BenefitSection from '../components/BenefitSection';
import SolutionSection from '../components/SolutionSection';
import IntroductionSection from '../components/IntroductionSection';
import TrustSection from '../components/TrustSection';
import ComparisonSection from '../components/ComparisonSection';
import StepSection from '../components/StepSection';
import PlanSection from '../components/PlanSection';
import FAQSection from '../components/FAQSection';
import CTASection from '../components/CTASection';
import PaymentForm from '../components/PaymentForm';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Hero />
      <ProblemSection />
      <BenefitSection />
      <SolutionSection />
      <IntroductionSection />
      <TrustSection />
      <ComparisonSection />
      <StepSection />
      <PlanSection />
      <FAQSection />
      <CTASection />
      <PaymentForm />
    </div>
  );
}