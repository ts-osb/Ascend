
import type { Metadata } from "next";
import { Geist, Geist_Mono, Pacifico } from "next/font/google";
import "./globals.css";

const pacifico = Pacifico({
  weight: '400',
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-pacifico',
})

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Ascend Baseball Salon - 次世代野球サロン",
  description: "未来の野球を創る次世代育成プログラム。データ分析、最新技術、個別指導で野球選手の可能性を最大限に引き出します。14日間無料体験実施中。",
  keywords: "野球,野球教室,野球指導,データ分析,トレーニング,ジュニア野球",
  openGraph: {
    title: "Ascend Baseball Salon - 次世代野球サロン",
    description: "未来の野球を創る次世代育成プログラム。データ分析、最新技術、個別指導で野球選手の可能性を最大限に引き出します。",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja" suppressHydrationWarning={true}>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${pacifico.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
