'use client';

import { useState } from 'react';

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "オンラインでの指導でも効果はありますか？",
      answer: "はい、効果的です。身体の仕組みの理解と正しいフォームの習得が最も重要で、これらはオンラインでも十分に学習できます。また、動画での動作解説や質問対応により、対面指導と同等の学習効果を実現しています。"
    },
    {
      question: "子どもの年齢制限はありますか？",
      answer: "小学生から大学生まで幅広く対応しています。成長期に合わせた指導内容となっており、年齢や発達段階に応じて適切なプログラムを提供いたします。"
    },
    {
      question: "パソコンやスマートフォンの操作が苦手でも大丈夫ですか？",
      answer: "大丈夫です。簡単な操作で利用できるよう設計されており、サポートも充実しています。分からないことがあれば、いつでもお気軽にお問い合わせください。"
    },
    {
      question: "他の習い事や部活との両立は可能ですか？",
      answer: "もちろん可能です。オンライン完結なので時間と場所を選ばず、お子様のスケジュールに合わせて学習できます。移動時間も不要なので、効率的に両立できます。"
    },
    {
      question: "無料期間中にキャンセルした場合、料金はかかりませんか？",
      answer: "14日間の無料期間中にキャンセルした場合、一切料金はかかりません。完全にリスクフリーでお試しいただけます。"
    },
    {
      question: "どのような機器が必要ですか？",
      answer: "スマートフォン、タブレット、パソコンのいずれかがあれば参加できます。動画視聴とライブ配信の視聴ができる環境があれば十分です。"
    },
    {
      question: "地方在住でも問題ありませんか？",
      answer: "全く問題ありません。むしろ、地方では受けられない質の高い指導をオンラインで提供することが当サロンの大きな目的の一つです。全国どこからでも同じサービスを受けられます。"
    },
    {
      question: "プランの変更は可能ですか？",
      answer: "はい、いつでもプラン変更が可能です。ベーシックからプレミアムへ、またはその逆への変更も簡単にできます。お子様の成長やニーズに合わせて柔軟に対応いたします。"
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            よくある<span className="text-green-600">質問</span>
          </h2>
          <p className="text-xl text-gray-600">
            保護者の皆様からよくいただくご質問にお答えします
          </p>
        </div>
        
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white border border-gray-200 rounded-xl overflow-hidden">
              <button
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition cursor-pointer"
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
              >
                <span className="font-semibold text-gray-900 pr-4">{faq.question}</span>
                <div className="w-6 h-6 flex items-center justify-center flex-shrink-0">
                  <i className={`ri-${openIndex === index ? 'subtract' : 'add'}-line text-green-600 text-xl`}></i>
                </div>
              </button>
              {openIndex === index && (
                <div className="px-6 pb-4">
                  <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">
              他にもご質問がございましたら
            </h3>
            <p className="text-gray-600 mb-6">
              お気軽にお問い合わせください。専門スタッフが丁寧にお答えいたします。
            </p>
            <button className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-lg font-semibold transition cursor-pointer whitespace-nowrap">
              <i className="ri-mail-line mr-2"></i>
              お問い合わせ
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}