
'use client';

import Link from 'next/link';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Beautiful%20baseball%20stadium%20field%20view%20from%20stands%2C%20professional%20baseball%20diamond%20with%20perfect%20green%20grass%2C%20dramatic%20sky%20with%20white%20clouds%2C%20stadium%20seating%20visible%2C%20peaceful%20empty%20field%20ready%20for%20dreams%2C%20cinematic%20wide%20angle%20view%20perfect%20for%20overlay%20text%2C%20inspiring%20baseball%20atmosphere&width=1920&height=1080&seq=hero2&orientation=landscape')`
        }}
      />
      
      {/* オーバーレイ */}
      <div className="absolute inset-0 bg-black/40"></div>
      
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 lg:px-8">
        <div className="text-center text-white">
          {/* メインタイトル */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl xl:text-8xl font-bold mb-6 md:mb-8 tracking-wider text-shadow-lg leading-tight">
            <span className="relative block">
              <span className="bg-gradient-to-r from-white via-gray-100 to-white bg-clip-text text-transparent drop-shadow-2xl">
                Ascend
              </span>
            </span>
            <span className="block my-2 md:my-0 md:mx-4 md:inline text-green-400 font-extrabold drop-shadow-2xl">
              Baseball
            </span>
            <span className="block md:inline bg-gradient-to-r from-white via-gray-100 to-white bg-clip-text text-transparent drop-shadow-2xl">
              Salon
            </span>
          </h1>
          
          {/* サブタイトル */}
          <div className="mb-8 md:mb-12">
            <h2 className="text-lg sm:text-xl md:text-2xl lg:text-4xl xl:text-5xl font-bold mb-2 md:mb-4 leading-tight text-white">
              全ての野球選手に
            </h2>
            <h2 className="text-lg sm:text-xl md:text-2xl lg:text-4xl xl:text-5xl font-bold mb-2 md:mb-4 leading-tight text-white">
              正しい方向性×努力を
            </h2>
            <h2 className="text-lg sm:text-xl md:text-2xl lg:text-4xl xl:text-5xl font-bold leading-tight text-white">
              継続する環境
            </h2>
          </div>
          
          {/* 説明文 */}
          <p className="text-base sm:text-lg md:text-xl lg:text-2xl mb-8 md:mb-12 max-w-4xl mx-auto font-medium text-white">
            野球に関わる選手・指導者・親御さんのためのオンラインサロン
          </p>
          
          {/* CTA ボタン */}
          <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center items-center">
            <button 
              onClick={() => document.getElementById('signup-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-green-600 hover:bg-green-700 text-white px-8 sm:px-10 md:px-12 py-3 md:py-4 rounded-full text-lg md:text-xl font-bold shadow-xl transform transition hover:scale-105 whitespace-nowrap cursor-pointer"
            >
              <i className="ri-play-circle-line mr-2"></i>
              14日間無料で体験開始
            </button>
          </div>
        </div>
      </div>
      
      <style jsx>{`
        .text-shadow-lg {
          text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.8);
        }
      `}</style>
    </section>
  );
}
