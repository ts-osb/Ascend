
'use client';

import { useState } from 'react';

export default function IntroductionSection() {
  const [showDetails, setShowDetails] = useState(false);

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            指導者<span className="text-green-600">紹介</span>
          </h2>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            {/* プロフィール画像 */}
            <div className="flex-shrink-0">
              <img 
                src="https://static.readdy.ai/image/b41a0fed24bd4fea04faab580ec91ca8/e7220a36c1cb644b238de646c45aaa30.jfif"
                alt="指導者プロフィール"
                className="w-48 h-48 lg:w-64 lg:h-64 rounded-full object-cover object-top shadow-xl"
              />
            </div>

            {/* 基本紹介 */}
            <div className="flex-1 text-center lg:text-left">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
                坂口 達哉
              </h3>
              <p className="text-lg text-green-600 font-semibold mb-6">
                野球パフォーマンスコーチ・S＆Cコーチ
              </p>
              
              <div className="space-y-4 text-gray-700 mb-8">
                <p className="text-lg">
                  小学生から社会人・独立リーグ選手まで幅広いカテゴリーの野球選手の指導を担当。自身の怪我と復帰の経験から生まれた「身体の仕組みに沿った正しいトレーニング」で選手をサポート。
                </p>
                <p className="text-lg">
                  複数の強豪校への進学サポートと教え子の甲子園出場実績を持つ、経験豊富なトレーナーです。
                </p>
              </div>

              <button 
                onClick={() => setShowDetails(!showDetails)}
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 rounded-full font-semibold transition transform hover:scale-105 cursor-pointer whitespace-nowrap"
              >
                <i className={`${showDetails ? 'ri-arrow-up-line' : 'ri-arrow-down-line'} mr-2`}></i>
                {showDetails ? '詳細を閉じる' : '詳細プロフィールを見る'}
              </button>
            </div>
          </div>

          {/* 詳細プロフィール */}
          {showDetails && (
            <div className="mt-12 pt-8 border-t border-gray-200 animate-in slide-in-from-top duration-300">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* 経歴・資格 */}
                <div>
                  <h4 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                    <i className="ri-medal-line text-green-600 mr-2"></i>
                    経歴・資格
                  </h4>
                  <div className="space-y-3 text-gray-700">
                    <div className="flex items-start space-x-2">
                      <i className="ri-check-line text-green-600 mt-1"></i>
                      <span>NSCA-CSCS（認定ストレングス&コンディショニングスペシャリスト）</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-check-line text-green-600 mt-1"></i>
                      <span>初芝橋本高校（和歌山県）主将</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-check-line text-green-600 mt-1"></i>
                      <span>東海学園大学（愛知県）4年春ベストナイン獲得</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-check-line text-green-600 mt-1"></i>
                      <span>病院併設ジムでの勤務経験</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-check-line text-green-600 mt-1"></i>
                      <span>大阪府堺市 パーソナルジムAscend Performance開業</span>
                    </div>
                  </div>
                </div>

                {/* 指導実績・経験 */}
                <div>
                  <h4 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                    <i className="ri-trophy-line text-green-600 mr-2"></i>
                    指導実績・経験
                  </h4>
                  <div className="space-y-3 text-gray-700">
                    <div className="flex items-start space-x-2">
                      <i className="ri-star-fill text-yellow-500 mt-1"></i>
                      <span>少年野球チーム指導</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-star-fill text-yellow-500 mt-1"></i>
                      <span>中学ボーイズリーグ指導</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-star-fill text-yellow-500 mt-1"></i>
                      <span>大学野球チーム指導</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-star-fill text-yellow-500 mt-1"></i>
                      <span>複数の強豪校への進学サポート</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-star-fill text-yellow-500 mt-1"></i>
                      <span>教え子の甲子園出場実績</span>
                    </div>
                  </div>
                </div>

                {/* 多様な指導経験 */}
                <div>
                  <h4 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                    <i className="ri-team-line text-green-600 mr-2"></i>
                    多様な指導経験
                  </h4>
                  <div className="space-y-3 text-gray-700">
                    <div className="flex items-start space-x-2">
                      <i className="ri-basketball-line text-blue-500 mt-1"></i>
                      <span>野球・ゴルフ・バスケ・サッカー・チア・バレーなど多種目対応</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-user-line text-blue-500 mt-1"></i>
                      <span>4歳〜90歳までの幅広い年齢層への運動指導</span>
                    </div>
                    <div className="flex items-start space-x-2">
                      <i className="ri-hospital-line text-blue-500 mt-1"></i>
                      <span>病院併設ジムでの勤務経験</span>
                    </div>
                  </div>
                </div>

                {/* 指導方針 */}
                <div className="md:col-span-2">
                  <h4 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                    <i className="ri-heart-pulse-line text-green-600 mr-2"></i>
                    指導方針
                  </h4>
                  <div className="bg-green-50 p-6 rounded-xl">
                    <p className="text-gray-700 text-lg leading-relaxed">
                      自身の怪我と復帰の実体験から、「身体の仕組みに沿った正しいトレーニング」の重要性を深く理解しています。単なる練習ではなく、科学的根拠に基づいたトレーニングとコンディショニングで、選手一人ひとりの可能性を最大限に引き出します。怪我の予防から競技力向上まで、トータルでサポートします。
                    </p>
                  </div>
                </div>

                {/* メッセージ */}
                <div className="md:col-span-2">
                  <h4 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                    <i className="ri-message-3-line text-green-600 mr-2"></i>
                    保護者・選手の皆様へ
                  </h4>
                  <div className="bg-blue-50 p-6 rounded-xl border-l-4 border-blue-500">
                    <p className="text-gray-700 text-lg leading-relaxed italic">
                      私は選手として挫折も経験しました。だからこそ、正しい知識と適切なトレーニングの価値を誰よりも理解しています。怪我で悩んでいる選手、もっと上達したい選手、すべての野球選手の力になりたいと思っています。一緒に、野球を通じた成長と夢の実現を目指しましょう。
                    </p>
                    <p className="text-right text-gray-600 mt-4 font-semibold">
                      - 坂口 達哉
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
