
'use client';

import { useState } from 'react';

export default function PaymentForm() {
  const [selectedPlan, setSelectedPlan] = useState('basic');
  const [formData, setFormData] = useState({
    parentName: '',
    parentEmail: '',
    parentPhone: '',
    childName: '',
    childAge: '',
    childGrade: '',
    experience: '',
    goals: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: '',
    terms: false,
    privacy: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');
  const [showTerms, setShowTerms] = useState(false);
  const [showPrivacy, setShowPrivacy] = useState(false);

  const handleInputChange = (e) => {
    const { name, value, type } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? e.target.checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    // 仮の送信処理（実際の決済処理は後で実装）
    try {
      // 実際の送信を模擬
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setSubmitStatus('お申し込みありがとうございます！担当者より2営業日以内にご連絡いたします。');
      setFormData({
        parentName: '',
        parentEmail: '',
        parentPhone: '',
        childName: '',
        childAge: '',
        childGrade: '',
        experience: '',
        goals: '',
        cardNumber: '',
        expiryDate: '',
        cvv: '',
        cardName: '',
        terms: false,
        privacy: false
      });
    } catch (error) {
      setSubmitStatus('送信に失敗しました。もう一度お試しください。');
    }

    setIsSubmitting(false);
  };

  return (
    <section id="signup-form" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            <span className="text-green-600">14日間無料トライアル</span>お申し込み
          </h2>
          <p className="text-xl text-gray-600">
            以下の情報をご入力ください。お申し込み完了後、すぐに利用開始できます。
          </p>
        </div>

        <form id="ascend-signup" onSubmit={handleSubmit} className="bg-gray-50 p-8 rounded-xl">
          <div className="mb-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">プラン選択</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className={`cursor-pointer border-2 rounded-lg p-4 transition ${selectedPlan === 'basic' ? 'border-green-500 bg-green-50' : 'border-gray-300 bg-white'}`}>
                <input
                  type="radio"
                  name="plan"
                  value="basic"
                  checked={selectedPlan === 'basic'}
                  onChange={(e) => setSelectedPlan(e.target.value)}
                  className="sr-only"
                />
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-900">ベーシックプラン</h4>
                    <p className="text-gray-600 text-sm">基本的な指導内容</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">¥2,000</div>
                    <div className="text-gray-600 text-sm">/月</div>
                  </div>
                </div>
              </label>

              <label className={`cursor-pointer border-2 rounded-lg p-4 transition ${selectedPlan === 'premium' ? 'border-blue-500 bg-blue-50' : 'border-gray-300 bg-white'}`}>
                <input
                  type="radio"
                  name="plan"
                  value="premium"
                  checked={selectedPlan === 'premium'}
                  onChange={(e) => setSelectedPlan(e.target.value)}
                  className="sr-only"
                />
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-gray-900">プレミアムプラン</h4>
                    <p className="text-gray-600 text-sm">ベーシック+個別対応</p>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-blue-600">¥10,000</div>
                    <div className="text-gray-600 text-sm">/月</div>
                  </div>
                </div>
              </label>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label htmlFor="parentName" className="block text-sm font-semibold text-gray-700 mb-2">
                保護者氏名 <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="parentName"
                name="parentName"
                value={formData.parentName}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                placeholder="田中太郎"
              />
            </div>

            <div>
              <label htmlFor="parentEmail" className="block text-sm font-semibold text-gray-700 mb-2">
                メールアドレス <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                id="parentEmail"
                name="parentEmail"
                value={formData.parentEmail}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                placeholder="example@email.com"
              />
            </div>

            <div>
              <label htmlFor="parentPhone" className="block text-sm font-semibold text-gray-700 mb-2">
                電話番号 <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                id="parentPhone"
                name="parentPhone"
                value={formData.parentPhone}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                placeholder="090-1234-5678"
              />
            </div>

            <div>
              <label htmlFor="childName" className="block text-sm font-semibold text-gray-700 mb-2">
                お子様のお名前 <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="childName"
                name="childName"
                value={formData.childName}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                placeholder="田中一郎"
              />
            </div>

            <div>
              <label htmlFor="childAge" className="block text-sm font-semibold text-gray-700 mb-2">
                年齢 <span className="text-red-500">*</span>
              </label>
              <select
                id="childAge"
                name="childAge"
                value={formData.childAge}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
              >
                <option value="">選択してください</option>
                <option value="6">6歳</option>
                <option value="7">7歳</option>
                <option value="8">8歳</option>
                <option value="9">9歳</option>
                <option value="10">10歳</option>
                <option value="11">11歳</option>
                <option value="12">12歳</option>
                <option value="13">13歳</option>
                <option value="14">14歳</option>
                <option value="15">15歳</option>
                <option value="16">16歳</option>
                <option value="17">17歳</option>
                <option value="18">18歳</option>
                <option value="19">19歳</option>
                <option value="20">20歳</option>
                <option value="21">21歳</option>
                <option value="22">22歳</option>
              </select>
            </div>

            <div>
              <label htmlFor="childGrade" className="block text-sm font-semibold text-gray-700 mb-2">
                学年 <span className="text-red-500">*</span>
              </label>
              <select
                id="childGrade"
                name="childGrade"
                value={formData.childGrade}
                onChange={handleInputChange}
                required
                className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
              >
                <option value="">選択してください</option>
                <option value="小学1年生">小学1年生</option>
                <option value="小学2年生">小学2年生</option>
                <option value="小学3年生">小学3年生</option>
                <option value="小学4年生">小学4年生</option>
                <option value="小学5年生">小学5年生</option>
                <option value="小学6年生">小学6年生</option>
                <option value="中学1年生">中学1年生</option>
                <option value="中学2年生">中学2年生</option>
                <option value="中学3年生">中学3年生</option>
                <option value="高校1年生">高校1年生</option>
                <option value="高校2年生">高校2年生</option>
                <option value="高校3年生">高校3年生</option>
                <option value="大学1年生">大学1年生</option>
                <option value="大学2年生">大学2年生</option>
                <option value="大学3年生">大学3年生</option>
                <option value="大学4年生">大学4年生</option>
                <option value="社会人">社会人</option>
              </select>
            </div>
          </div>

          <div className="mb-6">
            <label htmlFor="experience" className="block text-sm font-semibold text-gray-700 mb-2">
              野球経験・現在の所属チーム
            </label>
            <input
              type="text"
              id="experience"
              name="experience"
              value={formData.experience}
              onChange={handleInputChange}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
              placeholder="○○中学校野球部、○○リトルリーグ等"
            />
          </div>

          <div className="mb-6">
            <label htmlFor="goals" className="block text-sm font-semibold text-gray-700 mb-2">
              目標・改善したいこと
            </label>
            <textarea
              id="goals"
              name="goals"
              value={formData.goals}
              onChange={handleInputChange}
              rows={4}
              maxLength={500}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm resize-none"
              placeholder="プロ野球選手になりたい、打率を上げたい、怪我をしにくい身体作りをしたい等（500文字以内）"
            />
            <div className="text-right text-sm text-gray-500 mt-1">
              {formData.goals.length}/500文字
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">クレジットカード情報</h3>
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg mb-4">
              <p className="text-sm text-blue-700">
                <i className="ri-information-line mr-1"></i>
                14日間の無料期間中は請求されません。無料期間終了前にご案内いたします。
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label htmlFor="cardNumber" className="block text-sm font-semibold text-gray-700 mb-2">
                  カード番号 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="cardNumber"
                  name="cardNumber"
                  value={formData.cardNumber}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                  placeholder="1234 5678 9012 3456"
                  maxLength={19}
                />
              </div>
              <div>
                <label htmlFor="expiryDate" className="block text-sm font-semibold text-gray-700 mb-2">
                  有効期限 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="expiryDate"
                  name="expiryDate"
                  value={formData.expiryDate}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                  placeholder="MM/YY"
                  maxLength={5}
                />
              </div>
              <div>
                <label htmlFor="cvv" className="block text-sm font-semibold text-gray-700 mb-2">
                  CVV <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="cvv"
                  name="cvv"
                  value={formData.cvv}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                  placeholder="123"
                  maxLength={4}
                />
              </div>
              <div className="md:col-span-2">
                <label htmlFor="cardName" className="block text-sm font-semibold text-gray-700 mb-2">
                  カード名義 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  id="cardName"
                  name="cardName"
                  value={formData.cardName}
                  onChange={handleInputChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 text-sm"
                  placeholder="TANAKA TARO"
                />
              </div>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <label className="flex items-start space-x-3 cursor-pointer">
              <input
                type="checkbox"
                name="terms"
                checked={formData.terms}
                onChange={handleInputChange}
                required
                className="mt-1 w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
              />
              <span className="text-sm text-gray-700">
                <span className="text-red-500">*</span> 
                <button 
                  type="button"
                  onClick={() => setShowTerms(true)}
                  className="text-green-600 hover:text-green-700 underline cursor-pointer"
                >
                  利用規約
                </button>
                に同意します
              </span>
            </label>

            <label className="flex items-start space-x-3 cursor-pointer">
              <input
                type="checkbox"
                name="privacy"
                checked={formData.privacy}
                onChange={handleInputChange}
                required
                className="mt-1 w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
              />
              <span className="text-sm text-gray-700">
                <span className="text-red-500">*</span> 
                <button 
                  type="button"
                  onClick={() => setShowPrivacy(true)}
                  className="text-green-600 hover:text-green-700 underline cursor-pointer"
                >
                  プライバシーポリシー
                </button>
                に同意します
              </span>
            </label>
          </div>

          <button
            type="submit"
            disabled={isSubmitting || !formData.terms || !formData.privacy}
            className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 disabled:from-gray-400 disabled:to-gray-400 text-white py-4 rounded-lg text-lg font-semibold transition cursor-pointer whitespace-nowrap"
          >
            {isSubmitting ? (
              <>
                <i className="ri-loader-4-line animate-spin mr-2"></i>
                送信中...
              </>
            ) : (
              <>
                <i className="ri-send-plane-line mr-2"></i>
                14日間無料トライアルを開始する
              </>
            )}
          </button>

          {submitStatus && (
            <div className={`mt-4 p-4 rounded-lg text-center ${submitStatus.includes('ありがとう') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
              {submitStatus}
            </div>
          )}

          <div className="mt-6 text-center text-sm text-gray-600">
            <p className="mb-2">
              <i className="ri-shield-check-line text-green-600 mr-1"></i>
              14日間完全無料・安心のセキュリティ
            </p>
            <p>
              <i className="ri-customer-service-line text-blue-600 mr-1"></i>
              ご不明な点がございましたら、お気軽にお問い合わせください
            </p>
          </div>
        </form>

        {/* 利用規約モーダル */}
        {showTerms && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-4xl max-h-[80vh] overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">利用規約</h3>
                <button
                  onClick={() => setShowTerms(false)}
                  className="text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <i className="ri-close-line text-2xl"></i>
                </button>
              </div>
              <div className="p-6 overflow-y-auto max-h-[60vh]">
                <div className="prose prose-sm max-w-none">
                  <p className="mb-4 text-gray-600">最終更新日: 2024年1月1日</p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第1条 総則</h4>
                  <p className="mb-4">
                    本利用規約（以下「本規約」）は、Ascend Baseball Salon（以下「当サービス」）の利用条件を定めるものです。利用者は本規約に同意した上でサービスをご利用ください。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第2条 サービス内容</h4>
                  <p className="mb-4">
                    当サービスは、野球に関する技術指導、理論解説、練習方法等の情報をオンライン上で提供するサービスです。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第3条 利用申込み</h4>
                  <p className="mb-4">
                    1. 利用申込みは、本規約に同意の上、所定の申込手続きを完了することで成立します。<br/>
                    2. 未成年者の場合は、保護者の同意が必要です。<br/>
                    3. 虚偽の情報での申込みは禁止します。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第4条 料金・支払い</h4>
                  <p className="mb-4">
                    1. 利用料金は各プランページに記載の通りです。<br/>
                    2. 14日間の無料体験期間を設けています。<br/>
                    3. 料金は月額制で、毎月同日に自動決済されます。<br/>
                    4. 料金の返金は原則として行いません。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第5条 利用者の義務</h4>
                  <p className="mb-4">
                    1. サービス利用に必要な機器・環境は利用者が準備してください。<br/>
                    2. 他の利用者に迷惑をかける行為は禁止します。<br/>
                    3. サービス内容の無断転載・複製を禁止します。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第6条 禁止事項</h4>
                  <p className="mb-4">
                    1. 法令に違反する行為<br/>
                    2. 他者の権利を侵害する行為<br/>
                    3. サービスの運営を妨害する行為<br/>
                    4. 不適切な内容の投稿・発信
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第7条 解約</h4>
                  <p className="mb-4">
                    利用者はいつでも解約することができます。解約手続きは所定の方法で行ってください。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第8条 免責事項</h4>
                  <p className="mb-4">
                    当サービスの利用により生じた損害について、当社は一切の責任を負いません。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第9条 規約の変更</h4>
                  <p className="mb-4">
                    当社は必要に応じて本規約を変更することがあります。変更時は事前にお知らせいたします。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第10条 準拠法・管轄</h4>
                  <p className="mb-4">
                    本規約は日本法に準拠し、東京地方裁判所を専属的合意管轄とします。
                  </p>
                </div>
              </div>
              <div className="px-6 py-4 border-t border-gray-200 text-center">
                <button
                  onClick={() => setShowTerms(false)}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-semibold cursor-pointer"
                >
                  閉じる
                </button>
              </div>
            </div>
          </div>
        )}

        {/* プライバシーポリシーモーダル */}
        {showPrivacy && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-4xl max-h-[80vh] overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">プライバシーポリシー</h3>
                <button
                  onClick={() => setShowPrivacy(false)}
                  className="text-gray-400 hover:text-gray-600 cursor-pointer"
                >
                  <i className="ri-close-line text-2xl"></i>
                </button>
              </div>
              <div className="p-6 overflow-y-auto max-h-[60vh]">
                <div className="prose prose-sm max-w-none">
                  <p className="mb-4 text-gray-600">最終更新日: 2024年1月1日</p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第1条 個人情報の定義</h4>
                  <p className="mb-4">
                    本プライバシーポリシーにおいて、個人情報とは個人情報保護法に定める個人情報を指します。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第2条 収集する個人情報</h4>
                  <p className="mb-4">
                    当サービスでは、以下の個人情報を収集いたします：<br/>
                    1. 氏名、年齢、学年<br/>
                    2. メールアドレス、電話番号<br/>
                    3. 野球経験、目標等のサービス利用に関する情報<br/>
                    4. 決済に必要なクレジットカード情報<br/>
                    5. サービス利用履歴
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第3条 利用目的</h4>
                  <p className="mb-4">
                    収集した個人情報は以下の目的で利用いたします：<br/>
                    1. サービスの提供・運営<br/>
                    2. 利用者への連絡・サポート<br/>
                    3. 料金決済の処理<br/>
                    4. サービス改善のための分析<br/>
                    5. 新サービス・キャンペーンのご案内
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第4条 第三者への提供</h4>
                  <p className="mb-4">
                    当社は、法令に基づく場合を除き、利用者の同意なく第三者に個人情報を提供いたしません。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第5条 個人情報の管理</h4>
                  <p className="mb-4">
                    当社は個人情報を適切に管理し、不正アクセス・紛失・破損・漏洩の防止に努めます。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第6条 クッキーの使用</h4>
                  <p className="mb-4">
                    当サービスでは、サービス向上のためクッキーを使用する場合があります。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第7条 開示・訂正・削除</h4>
                  <p className="mb-4">
                    利用者は、自身の個人情報について開示・訂正・削除を求めることができます。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第8条 お問い合わせ</h4>
                  <p className="mb-4">
                    個人情報の取扱いに関するご質問・ご要望は、当社までお問い合わせください。
                  </p>

                  <h4 className="text-lg font-semibold mt-6 mb-3">第9条 プライバシーポリシーの変更</h4>
                  <p className="mb-4">
                    当社は必要に応じて本ポリシーを変更することがあります。変更時は当サイト上でお知らせいたします。
                  </p>
                </div>
              </div>
              <div className="px-6 py-4 border-t border-gray-200 text-center">
                <button
                  onClick={() => setShowPrivacy(false)}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-semibold cursor-pointer"
                >
                  閉じる
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
