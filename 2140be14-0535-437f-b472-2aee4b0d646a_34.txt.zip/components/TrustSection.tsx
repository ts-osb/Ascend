
'use client';

export default function TrustSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            なぜ選ばれるのか？<br />
            <span className="text-green-600">3つの信頼性</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          <div className="text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-trophy-line text-green-600 text-3xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">豊富な指導実績</h3>
            <p className="text-gray-600">
              小学生から社会人・独立リーグ選手まで、<br />
              幅広いレベルでの指導実績と成果
            </p>
          </div>

          <div className="text-center">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-user-heart-line text-blue-600 text-3xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">保護者・選手の推薦</h3>
            <p className="text-gray-600">
              実際に結果を実感した保護者・選手からの<br />
              信頼と推薦の声
            </p>
          </div>

          <div className="text-center">
            <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-heart-pulse-line text-purple-600 text-3xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">専門性への信頼</h3>
            <p className="text-gray-600">
              怪我予防と成長期対応に特化した<br />
              科学的アプローチ
            </p>
          </div>
        </div>

        <div className="bg-gray-50 p-8 rounded-xl">
          <h3 className="text-2xl font-semibold text-gray-900 mb-8 text-center">会員様の声</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center mr-4 shadow-sm">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-300 to-gray-400 shadow-inner"></div>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">T.Y様（保護者）</p>
                  <p className="text-gray-600 text-sm">中学2年生の母</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                「息子の野球への取り組み方が変わりました。身体の使い方を理解してからは、怪我もなく、むしろパフォーマンスが向上。親としても安心して応援できます。」
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center mr-4 shadow-sm">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-300 to-gray-400 shadow-inner"></div>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">S.K選手</p>
                  <p className="text-gray-600 text-sm">少年野球コーチ</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                「なぜそのトレーニングが必要なのかが分かるようになってから、練習の質が大きく変わりました。選手もより積極的に取り組んでくれるようになりました。」
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center mr-4 shadow-sm">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-300 to-gray-400 shadow-inner"></div>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">Y.T様（保護者）</p>
                  <p className="text-gray-600 text-sm">小学6年生の父</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                「地方に住んでいても質の高い指導を受けられるのが何より魅力的。息子の成長を実感でき、野球への情熱も以前より増しています。」
              </p>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center mr-4 shadow-sm">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-300 to-gray-400 shadow-inner"></div>
                </div>
                <div>
                  <p className="font-semibold text-gray-900">S.R選手</p>
                  <p className="text-gray-600 text-sm">大学2年生</p>
                </div>
              </div>
              <p className="text-gray-700 italic">
                「継続的なサポートがあるおかげで、モチベーションを維持できています。オンラインパーソナルでは、自分の課題を具体的に解決してもらえて本当に助かっています。」
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
