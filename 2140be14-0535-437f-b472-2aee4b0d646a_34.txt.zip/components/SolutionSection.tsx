
'use client';

export default function SolutionSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Ascend Baseball Salonの<span className="text-green-600">解決策</span>
          </h2>
          <p className="text-xl text-gray-600">
            科学的アプローチと個別サポートで、お子様の可能性を最大限に引き出します
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              <span className="text-green-600">科学的根拠</span>に基づいた指導
            </h3>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-microscope-line text-green-600 text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">身体の仕組みから理解</h4>
                  <p className="text-gray-600">筋肉・骨格・神経系の働きを理解した上で、効率的な動作を身につけます。</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-heart-pulse-line text-blue-600 text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">成長期専用プログラム</h4>
                  <p className="text-gray-600">年齢・成長段階に合わせたトレーニングで怪我を予防し、確実にレベルアップ。</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-line-chart-line text-purple-600 text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">実績のあるメソッド</h4>
                  <p className="text-gray-600">小学生から社会人・独立リーグ選手まで、多数の指導実績があります。</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://readdy.ai/api/search-image?query=Professional%20baseball%20training%20facility%20with%20scientific%20equipment%20and%20analysis%20tools%2C%20modern%20sports%20training%20environment%2C%20anatomical%20charts%20and%20training%20materials%20on%20walls%2C%20clean%20organized%20space%20for%20athletic%20development%2C%20professional%20coaching%20setup%20with%20technology%20integration&width=600&height=400&seq=solution1&orientation=landscape"
              alt="科学的トレーニング環境"
              className="rounded-xl shadow-lg object-cover object-top w-full h-80"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div className="lg:order-2">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              <span className="text-blue-600">個別対応</span>で確実な成長
            </h3>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-question-answer-line text-green-600 text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">質問・相談対応</h4>
                  <p className="text-gray-600">技術的な疑問から練習方法まで、何でもお気軽にご相談いただけます。</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-video-line text-blue-600 text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">動作解説・フィードバック</h4>
                  <p className="text-gray-600">お子様の動画を見て、具体的な改善ポイントをお伝えします。</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-calendar-check-line text-purple-600 text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">オンラインパーソナル</h4>
                  <p className="text-gray-600">プレミアムプランでは月1回、マンツーマンでの指導を受けられます。</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="lg:order-1 relative">
            <img 
              src="https://readdy.ai/api/search-image?query=Online%20baseball%20coaching%20session%20with%20coach%20and%20young%20player%20on%20video%20call%2C%20computer%20screen%20showing%20baseball%20technique%20analysis%2C%20personalized%20instruction%20environment%2C%20modern%20technology%20for%20remote%20coaching%2C%20professional%20sports%20education%20setting&width=600&height=400&seq=solution2&orientation=landscape"
              alt="オンライン個別指導"
              className="rounded-xl shadow-lg object-cover object-top w-full h-80"
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              <span className="text-purple-600">継続できる</span>サポート体制
            </h3>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-live-line text-green-600 text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">ライブトレーニング</h4>
                  <p className="text-gray-600">定期的なライブセッションで、モチベーションを保ち続けます。</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-team-line text-blue-600 text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">コミュニティ</h4>
                  <p className="text-gray-600">同じ目標を持つ仲間との情報交換や体験共有ができます。</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-book-open-line text-purple-600 text-xl"></i>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">豊富なコンテンツ</h4>
                  <p className="text-gray-600">技術だけでなく、メンタル面やケア方法なども学べます。</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://readdy.ai/api/search-image?query=Baseball%20community%20and%20support%20system%20with%20multiple%20young%20players%20training%20together%2C%20motivational%20group%20environment%2C%20supportive%20coaching%20atmosphere%2C%20team%20building%20activities%20for%20baseball%20development%2C%20encouraging%20sports%20community%20setting&width=600&height=400&seq=solution3&orientation=landscape"
              alt="サポートコミュニティ"
              className="rounded-xl shadow-lg object-cover object-top w-full h-80"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
