
'use client';

export default function ComparisonSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            他社との<span className="text-green-600">違い</span>
          </h2>
          <p className="text-xl text-gray-600">
            なぜAscend Baseball Salonが選ばれるのか、その理由をご覧ください
          </p>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-green-50">
                <tr>
                  <th className="px-6 py-4 text-left font-semibold text-gray-900">比較項目</th>
                  <th className="px-6 py-4 text-center font-semibold text-green-600 bg-green-100">
                    Ascend Baseball Salon
                  </th>
                  <th className="px-6 py-4 text-center font-semibold text-gray-600">一般的な野球教室</th>
                  <th className="px-6 py-4 text-center font-semibold text-gray-600">YouTube等の動画</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 font-semibold text-gray-900">科学的根拠</td>
                  <td className="px-6 py-4 text-center bg-green-50">
                    <i className="ri-check-line text-green-600 text-xl"></i>
                    <div className="text-sm text-gray-700 mt-1">身体の仕組みから理解</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-close-line text-red-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">経験則中心</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-subtract-line text-yellow-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">情報が断片的</div>
                  </td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="px-6 py-4 font-semibold text-gray-900">個別対応</td>
                  <td className="px-6 py-4 text-center bg-green-50">
                    <i className="ri-check-line text-green-600 text-xl"></i>
                    <div className="text-sm text-gray-700 mt-1">質問対応・動作解説</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-subtract-line text-yellow-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">グループ指導のみ</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-close-line text-red-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">一方向の情報のみ</div>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 font-semibold text-gray-900">継続サポート</td>
                  <td className="px-6 py-4 text-center bg-green-50">
                    <i className="ri-check-line text-green-600 text-xl"></i>
                    <div className="text-sm text-gray-700 mt-1">ライブ・コミュニティ</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-close-line text-red-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">レッスン時のみ</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-close-line text-red-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">サポートなし</div>
                  </td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="px-6 py-4 font-semibold text-gray-900">アクセス性</td>
                  <td className="px-6 py-4 text-center bg-green-50">
                    <i className="ri-check-line text-green-600 text-xl"></i>
                    <div className="text-sm text-gray-700 mt-1">全国どこからでも</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-close-line text-red-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">通える範囲のみ</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-check-line text-green-600 text-xl"></i>
                    <div className="text-sm text-gray-700 mt-1">どこからでも視聴可</div>
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 font-semibold text-gray-900">成長期対応</td>
                  <td className="px-6 py-4 text-center bg-green-50">
                    <i className="ri-check-line text-green-600 text-xl"></i>
                    <div className="text-sm text-gray-700 mt-1">専門的な怪我予防</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-subtract-line text-yellow-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">指導者による差</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-close-line text-red-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">個人の判断任せ</div>
                  </td>
                </tr>
                <tr className="bg-gray-50">
                  <td className="px-6 py-4 font-semibold text-gray-900">コスト</td>
                  <td className="px-6 py-4 text-center bg-green-50">
                    <i className="ri-check-line text-green-600 text-xl"></i>
                    <div className="text-sm text-gray-700 mt-1">月額2,000円〜</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-close-line text-red-500 text-xl"></i>
                    <div className="text-sm text-gray-600 mt-1">月数万円＋交通費</div>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <i className="ri-check-line text-green-600 text-xl"></i>
                    <div className="text-sm text-gray-700 mt-1">無料</div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-8 rounded-xl">
            <h3 className="text-2xl font-bold mb-4">
              <i className="ri-star-fill text-yellow-300 mr-2"></i>
              6つの要素を高いレベルで実現
            </h3>
            <p className="text-lg">
              科学的根拠・個別対応・継続サポート・アクセス性・専門性・コストパフォーマンス<br />
              これらを総合的にバランス良く提供できるよう取り組んでいます
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
