'use client';

export default function PlanSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            選べる<span className="text-green-600">2つのプラン</span>
          </h2>
          <p className="text-xl text-gray-600">
            あなたの目標とニーズに合わせてお選びください
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <div className="bg-white border-2 border-gray-200 rounded-xl p-8 relative">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">ベーシックプラン</h3>
              <div className="flex items-center justify-center mb-4">
                <span className="text-4xl font-bold text-green-600">¥2,000</span>
                <span className="text-gray-600 ml-2">/月</span>
              </div>
              <p className="text-gray-600">まずは基本的な指導から始めたい方に</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center space-x-3">
                <i className="ri-check-line text-green-600 text-xl"></i>
                <span className="text-gray-700">プレー動画の解説(月２回）</span>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-check-line text-green-600 text-xl"></i>
                <span className="text-gray-700">質問回答</span>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-check-line text-green-600 text-xl"></i>
                <span className="text-gray-700">エクササイズ・トレーニング・ドリル紹介</span>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-check-line text-green-600 text-xl"></i>
                <span className="text-gray-700">ライブグループトレーニング</span>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-check-line text-green-600 text-xl"></i>
                <span className="text-gray-700">コラム（トレーニングや技術以外）</span>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-check-line text-green-600 text-xl"></i>
                <span className="text-gray-700">対面指導割引</span>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-check-line text-green-600 text-xl"></i>
                <span className="text-gray-700">会員様の取り組み＆経験の共有</span>
              </div>
            </div>

            <button className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-semibold transition cursor-pointer whitespace-nowrap">
              ベーシックプランを選択
            </button>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-300 rounded-xl p-8 relative">
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-4 py-1 rounded-full text-sm font-semibold">
                おすすめ
              </span>
            </div>

            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">プレミアムプラン</h3>
              <div className="flex items-center justify-center mb-4">
                <span className="text-4xl font-bold text-blue-600">¥10,000</span>
                <span className="text-gray-600 ml-2">/月</span>
              </div>
              <p className="text-gray-600">本格的に上達したい方におすすめ</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="bg-white/70 p-3 rounded-lg">
                <p className="text-sm font-semibold text-gray-900 mb-2">ベーシックプランの全機能に加えて：</p>
              </div>

              <div className="flex items-center space-x-3">
                <i className="ri-star-fill text-blue-600 text-xl"></i>
                <span className="text-gray-700 font-semibold">個別メニュー作成</span>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-star-fill text-blue-600 text-xl"></i>
                <span className="text-gray-700 font-semibold">動作解説 無制限</span>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-star-fill text-blue-600 text-xl"></i>
                <span className="text-gray-700 font-semibold">月1回のオンラインパーソナル（50分）</span>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-lg mt-4">
                <p className="text-sm text-yellow-800">
                  <i className="ri-information-line mr-1"></i>
                  メニュー作成・オンラインパーソナルは入会から15日以降に開始
                </p>
              </div>
            </div>

            <button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 rounded-lg font-semibold transition cursor-pointer whitespace-nowrap">
              プレミアムプランを選択
            </button>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-green-50 border-2 border-green-200 p-8 rounded-xl max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-green-800 mb-4">
              <i className="ri-gift-line mr-2"></i>
              14日間無料トライアル
            </h3>
            <p className="text-lg text-green-700 mb-6">
              どちらのプランも14日間無料でお試しいただけます。<br />
              リスクなしで、お子様に最適なプランを見つけてください。
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center justify-center space-x-2">
                <i className="ri-check-line text-green-600"></i>
                <span className="text-green-700">いつでもキャンセル可能</span>
              </div>
              <div className="flex items-center justify-center space-x-2">
                <i className="ri-check-line text-green-600"></i>
                <span className="text-green-700">違約金・解約手数料なし</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
