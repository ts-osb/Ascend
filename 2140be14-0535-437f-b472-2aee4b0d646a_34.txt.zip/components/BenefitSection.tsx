
'use client';

export default function BenefitSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            お子様が手に入れる<br />
            <span className="text-green-600">4つの大きな変化</span>
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="text-center bg-green-50 p-8 rounded-xl">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-heart-pulse-line text-green-600 text-2xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">ケガをしない丈夫な体</h3>
            <p className="text-gray-600">
              成長期に合わせた正しいトレーニングで、ケガに負けない強い体を作り、長く野球を続けられる基盤を築きます
            </p>
          </div>
          
          <div className="text-center bg-blue-50 p-8 rounded-xl">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-brain-line text-blue-600 text-2xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">自分で考える力</h3>
            <p className="text-gray-600">
              「なぜ」を理解することで、指導者がいなくても自分で判断し、効率よく上達できる選手になります
            </p>
          </div>
          
          <div className="text-center bg-purple-50 p-8 rounded-xl">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-refresh-line text-purple-600 text-2xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">やる気が続く環境</h3>
            <p className="text-gray-600">
              仲間との切磋琢磨とコーチの励ましで、辛い練習も楽しく続けられ、自然と上達していきます
            </p>
          </div>
          
          <div className="text-center bg-orange-50 p-8 rounded-xl">
            <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <i className="ri-global-line text-orange-600 text-2xl"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-4">いつでもどこでも学べる</h3>
            <p className="text-gray-600">
              住んでいる場所や時間に関係なく、質の高い指導を受けられるので、お子様のペースで成長できます
            </p>
          </div>
        </div>
        
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-8 rounded-xl">
            <h3 className="text-2xl font-bold mb-4">その結果</h3>
            <p className="text-xl">
              お子様は野球が大好きになり、<br />
              <span className="font-bold text-yellow-300">プロを目指せる本物の実力</span>を身につけていきます
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
