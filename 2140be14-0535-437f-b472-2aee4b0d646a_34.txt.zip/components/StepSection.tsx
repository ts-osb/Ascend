
'use client';

import { useState } from 'react';

export default function StepSection() {
  const [activeStep, setActiveStep] = useState(1);

  const steps = [
    {
      id: 1,
      title: "こちらから申し込み",
      icon: "ri-rocket-line",
      color: "green",
      description: "14日間無料トライアルを開始",
      details: [
        "「14日間無料トライアル」ボタンをクリック",
        "クレジットカード情報を登録（Stripe / 世界基準の安全性）",
        "14日以内は完全無料"
      ]
    },
    {
      id: 2,
      title: "専用LINEに参加",
      icon: "ri-message-line",
      color: "blue",
      description: "すぐにサポート環境へアクセス",
      details: [
        "登録完了後、専用LINEの招待URLが届きます",
        "LINEで質問やサポートを受けられる環境に",
        "個別対応で安心のサポート体制"
      ]
    },
    {
      id: 3,
      title: "Facebookグループに招待",
      icon: "ri-group-line",
      color: "purple",
      description: "学習コンテンツへフルアクセス",
      details: [
        "LINEに届く専用リンクからFacebookグループへ参加",
        "コンテンツ視聴・動画配信が視聴可能に",
        "ライブ配信への参加権限を取得"
      ]
    },
    {
      id: 4,
      title: "学びと実践スタート",
      icon: "ri-play-circle-line",
      color: "orange",
      description: "本格的な野球上達プログラム開始",
      details: [
        "エクササイズ・トレーニング動画を見ながら自宅練習",
        "疑問はLINEで質問 → 後日まとめて動画解説",
        "ライブ配信で全国の仲間と一緒にトレーニング"
      ]
    },
    {
      id: 5,
      title: "継続か解約かを選択",
      icon: "ri-checkbox-circle-line",
      color: "red",
      description: "リスクフリーで判断",
      details: [
        "14日以内に解約すれば料金は一切発生なし",
        "継続すると自動で会員プラン（月額2,000円or10,000円）に移行",
        "途中からプレミアムプラン（月額10,000円）へのアップグレードも可能"
      ]
    }
  ];

  const getColorClasses = (color: string, isActive: boolean) => {
    const colors = {
      green: {
        bg: isActive ? 'bg-green-600' : 'bg-green-100',
        text: isActive ? 'text-white' : 'text-green-600',
        border: 'border-green-600',
        accent: 'text-green-600'
      },
      blue: {
        bg: isActive ? 'bg-blue-600' : 'bg-blue-100',
        text: isActive ? 'text-white' : 'text-blue-600',
        border: 'border-blue-600',
        accent: 'text-blue-600'
      },
      purple: {
        bg: isActive ? 'bg-purple-600' : 'bg-purple-100',
        text: isActive ? 'text-white' : 'text-purple-600',
        border: 'border-purple-600',
        accent: 'text-purple-600'
      },
      orange: {
        bg: isActive ? 'bg-orange-600' : 'bg-orange-100',
        text: isActive ? 'text-white' : 'text-orange-600',
        border: 'border-orange-600',
        accent: 'text-orange-600'
      },
      red: {
        bg: isActive ? 'bg-red-600' : 'bg-red-100',
        text: isActive ? 'text-white' : 'text-red-600',
        border: 'border-red-600',
        accent: 'text-red-600'
      }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            <span className="text-green-600">入会後の流れ</span>
          </h2>
          <p className="text-xl text-gray-600">
            申し込みから本格スタートまで、わずか5ステップ
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="space-y-6">
            {steps.map((step, index) => {
              const isActive = activeStep === step.id;
              const colors = getColorClasses(step.color, isActive);

              return (
                <div
                  key={step.id}
                  className={`cursor-pointer transition-all duration-300 ${isActive ? 'transform scale-105' : ''}`}
                  onClick={() => setActiveStep(step.id)}
                >
                  <div className={`p-6 rounded-xl border-2 ${isActive ? colors.border + ' bg-white shadow-lg' : 'border-gray-200 bg-white hover:shadow-md'}`}>
                    <div className="flex items-center space-x-4">
                      <div className={`w-12 h-12 flex items-center justify-center rounded-full ${colors.bg}`}>
                        <i className={`${step.icon} text-xl ${colors.text}`}></i>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <span className={`text-sm font-bold ${colors.accent}`}>
                            STEP {step.id}
                          </span>
                          <h3 className="text-lg font-bold text-gray-900">
                            {step.title}
                          </h3>
                        </div>
                        <p className="text-gray-600">{step.description}</p>
                      </div>
                      <div className={`w-6 h-6 flex items-center justify-center`}>
                        <i className={`ri-arrow-right-line ${isActive ? colors.accent : 'text-gray-400'}`}></i>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="lg:sticky lg:top-8">
            <div className="bg-white rounded-xl shadow-lg p-8 border">
              {steps.map((step) => {
                if (step.id !== activeStep) return null;
                const colors = getColorClasses(step.color, true);

                return (
                  <div key={step.id}>
                    <div className="flex items-center space-x-4 mb-6">
                      <div className={`w-16 h-16 flex items-center justify-center rounded-full ${colors.bg}`}>
                        <i className={`${step.icon} text-2xl ${colors.text}`}></i>
                      </div>
                      <div>
                        <div className={`text-sm font-bold ${colors.accent} mb-1`}>
                          STEP {step.id}
                        </div>
                        <h3 className="text-2xl font-bold text-gray-900">
                          {step.title}
                        </h3>
                      </div>
                    </div>

                    <div className="space-y-4">
                      {step.details.map((detail, index) => (
                        <div key={index} className="flex items-start space-x-3">
                          <div className={`w-2 h-2 rounded-full ${colors.bg} mt-2 flex-shrink-0`}></div>
                          <p className="text-gray-700 leading-relaxed">{detail}</p>
                        </div>
                      ))}
                    </div>

                    {step.id === 1 && (
                      <div className="mt-8 bg-green-50 border border-green-200 p-4 rounded-lg">
                        <div className="flex items-center space-x-2 mb-2">
                          <i className="ri-shield-check-line text-green-600"></i>
                          <span className="font-semibold text-green-800">完全リスクフリー</span>
                        </div>
                        <p className="text-sm text-green-700">
                          14日間は完全無料。期間内の解約で料金は一切発生しません。
                        </p>
                      </div>
                    )}

                    {step.id === 2 && (
                      <div className="mt-8 bg-blue-50 border border-blue-200 p-4 rounded-lg">
                        <div className="flex items-center space-x-2 mb-2">
                          <i className="ri-time-line text-blue-600"></i>
                          <span className="font-semibold text-blue-800">即時サポート</span>
                        </div>
                        <p className="text-sm text-blue-700">
                          登録後すぐにLINE招待が届き、質問やサポートを受けられます。
                        </p>
                      </div>
                    )}

                    {step.id === 5 && (
                      <div className="mt-8 bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                        <div className="flex items-center space-x-2 mb-2">
                          <i className="ri-information-line text-yellow-600"></i>
                          <span className="font-semibold text-yellow-800">柔軟なプラン変更</span>
                        </div>
                        <p className="text-sm text-yellow-700">
                          継続後もいつでもプラン変更や解約が可能です。
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-green-600 to-blue-600 p-8 rounded-xl text-white">
            <h3 className="text-2xl font-bold mb-4">
              まずは14日間、完全無料でお試しください
            </h3>
            <p className="text-lg mb-6 opacity-90">
              お子様の可能性を引き出す第一歩を、今すぐ踏み出しませんか？
            </p>
            <button 
              onClick={() => document.getElementById('signup-form')?.scrollIntoView({ behavior: 'smooth' })}
              className="bg-white text-green-600 hover:bg-gray-50 px-8 py-3 rounded-lg font-semibold transition cursor-pointer whitespace-nowrap"
            >
              <i className="ri-rocket-line mr-2"></i>
              14日間無料トライアルを開始
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
