'use client';

export default function ProblemSection() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            こんなお悩みありませんか？
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <i className="ri-close-line text-red-600"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">練習しても上達しない</h3>
                  <p className="text-gray-600">がむしゃらに練習しても、なかなか結果が出ない</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <i className="ri-close-line text-red-600"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">怪我が心配</h3>
                  <p className="text-gray-600">成長期の身体に負担をかけすぎていないか不安</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <i className="ri-close-line text-red-600"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">正しい指導が受けられない</h3>
                  <p className="text-gray-600">地方では専門的な指導を受ける機会が限られている</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <i className="ri-close-line text-red-600"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">継続できない</h3>
                  <p className="text-gray-600">モチベーションを維持するのが難しい</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://readdy.ai/api/search-image?query=Worried%20parent%20and%20young%20baseball%20player%20looking%20concerned%2C%20sitting%20together%20discussing%20baseball%20training%20challenges%2C%20emotional%20moment%20showing%20care%20and%20dedication%2C%20soft%20lighting%20creating%20empathetic%20atmosphere%2C%20clean%20background%2C%20realistic%20photography%20showing%20parent-child%20relationship%20in%20sports%20context&width=600&height=400&seq=problem1&orientation=landscape"
              alt="悩む保護者と選手"
              className="rounded-xl shadow-lg object-cover object-top w-full h-80"
            />
          </div>
        </div>
        
        <div className="mt-16 text-center">
          <p className="text-xl text-gray-700 font-medium">
            その結果、せっかくの才能を活かしきれず、<br />
            <span className="text-red-600 font-bold">夢を諦めてしまう選手が後を絶ちません。</span>
          </p>
        </div>
      </div>
    </section>
  );
}