
'use client';

export default function CTASection() {
  return (
    <section className="py-20 bg-gradient-to-br from-green-600 via-blue-600 to-purple-600 text-white relative overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-20"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Inspiring%20baseball%20field%20at%20sunset%20with%20dramatic%20lighting%2C%20professional%20baseball%20stadium%20atmosphere%2C%20empty%20field%20ready%20for%20training%2C%20motivational%20sports%20background%2C%20golden%20hour%20lighting%20creating%20dreams%20and%20aspirations%20mood%2C%20clean%20composition%20for%20overlay%20text&width=1920&height=1080&seq=cta1&orientation=landscape')`
        }}
      />
      
      <div className="relative z-10 max-w-4xl mx-auto px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-bold mb-6">
          お子様の野球人生を<br />
          今、変える決断を
        </h2>
        
        <p className="text-xl md:text-2xl mb-8 opacity-90">
          才能を開花させる14日間が、ここから始まります。<br />
          プロへの道筋を、科学的アプローチで切り拓きませんか？
        </p>
        
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold mb-2">14日間</div>
              <div className="text-lg opacity-90">完全無料トライアル</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">0円</div>
              <div className="text-lg opacity-90">初期費用・登録料</div>
            </div>
            <div>
              <div className="text-3xl font-bold mb-2">24時間</div>
              <div className="text-lg opacity-90">いつでも学習可能</div>
            </div>
          </div>
        </div>
        
        <div className="space-y-4">
          <button 
            onClick={() => document.getElementById('signup-form')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-white text-green-600 hover:bg-gray-50 px-12 py-4 rounded-full text-xl font-bold shadow-lg transform transition hover:scale-105 cursor-pointer whitespace-nowrap"
          >
            <i className="ri-rocket-line mr-3"></i>
            今すぐ14日間無料で始める
          </button>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-8 text-sm opacity-90">
            <div className="flex items-center space-x-2">
              <i className="ri-shield-check-line"></i>
              <span>リスク0の完全保証</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="ri-time-line"></i>
              <span>いつでもキャンセル可</span>
            </div>
            <div className="flex items-center space-x-2">
              <i className="ri-customer-service-line"></i>
              <span>充実のサポート体制</span>
            </div>
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-lg opacity-90 mb-4">
            迷っている時間が、お子様の可能性を狭めてしまいます。
          </p>
          <p className="text-xl font-semibold">
            未来のプロ野球選手への第一歩を、今踏み出してください。
          </p>
        </div>
      </div>
    </section>
  );
}
